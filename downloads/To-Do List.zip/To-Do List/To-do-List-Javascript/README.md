## TO-DO List

---

Simple application to organize tasks. It consists of a container that shows the day and time at the top, along with a dynamic background that changes depending on the time of day

It has the classic functionality in typical task management applications: add task, complete task, remove task.

You can try it at: [Todo List](https://raiben23.github.io/To-do-List-Javascript/)
